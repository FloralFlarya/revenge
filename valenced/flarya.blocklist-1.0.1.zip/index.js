(function () {
// Scoped adapter for the published Revenge bundles; no global vendetta dependency
function createCompatibility(api) {
    const v = api.unscoped;
    const { lookupModule, lookupModules, filters } = v.modules.finders;
    // These lookups always scan fresh exports, including modules loaded after startup
    // Keep a bounded set of cache keys because Staff Tags retries as screens load
    function matching(predicate, key = 'scan') {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(value && predicate(value)),
            () => `flarya.compat.${key}`,
        )();
    }
    const findByProps = (...props) => lookupModule(filters.withProps(...props), { cached: false })[0];
    const findByName = (name, defaultExport = true) =>
        lookupModule(filters.withName(name), { returnNamespace: !defaultExport, cached: false })[0];
    const findAll = predicate => [...lookupModules(matching(predicate), { cached: false })].map(([value]) => value);
    const findByStoreName = name => lookupModule(matching(value => typeof value.getName === 'function' && value.getName() === name, `store.${name}`), { cached: false })[0];
    const findByTypeNameAll = name => [...lookupModules(matching(value => value.type?.name === name, `type.${name}`), { cached: false })].map(([value]) => value);

    // Vendetta after hooks receive arguments and keep the result on undefined
    const after = (key, parent, hook) => v.patcher.instead(parent, key, function (args, original) {
        const result = original.apply(this, args);
        const replacement = hook.call(this, args, result);
        return replacement === undefined ? result : replacement;
    });
    const before = (key, parent, hook) => v.patcher.before(parent, key, args => hook(args) ?? args);

    const state = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const listeners = new Set();
    const proxies = new WeakMap();
    let writes = Promise.resolve();
    function persist() {
        const snapshot = JSON.parse(JSON.stringify(state));
        writes = writes.then(() => api.jsonStorage.set(snapshot, true));
        // Report storage failures while keeping later updates writable
        writes = writes.catch(error => console.error('Flarya plugin storage', error));
        for (const listener of listeners) listener();
    }
    function observable(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get(target, key) { return observable(target[key]); },
            set(target, key, next) { target[key] = next; persist(); return true; },
            deleteProperty(target, key) { delete target[key]; persist(); return true; },
        });
        proxies.set(value, proxy);
        return proxy;
    }
    function useProxy() {
        const [, render] = v.react.React.useReducer(n => n + 1, 0);
        v.react.React.useEffect(() => {
            listeners.add(render);
            return () => listeners.delete(render);
        }, []);
    }
    function findInReactTree(root, predicate) {
        const seen = new Set();
        function visit(node) {
            if (!node || typeof node !== 'object' || seen.has(node)) return;
            seen.add(node);
            if (predicate(node)) return node;
            const children = Array.isArray(node) ? node : [node.props?.children];
            for (const child of children) {
                const result = visit(child);
                if (result) return result;
            }
        }
        return visit(root);
    }
    function showToast(text, icon) {
        const toasts = v.discord.actions.ToastActionCreators;
        const key = `flarya-${Date.now()}`;
        if (toasts.open.length === 1) toasts.open({ key, content: text, icon });
        else {
            // Mana toasts render icon as a component, while Revenge passes an asset ID
            const Icon = typeof icon === 'number'
                ? props => v.react.React.createElement(v.react.ReactNative.Image, {
                    ...props, source: icon, style: [{ width: 24, height: 24 }, props?.style],
                })
                : icon;
            toasts.open(key, { text, icon: Icon });
        }
    }
    const commands = [];
    let removeCommands;
    function registerCommand(command) {
        const module = findByProps('getBuiltInCommands');
        if (!module) throw new Error('Discord command API is unavailable');
        if (!removeCommands) {
            removeCommands = after('getBuiltInCommands', module, ([types], result) => [
                ...result,
                ...commands.filter(item => (Array.isArray(types) ? types : [types]).includes(item.type)),
            ]);
            api.cleanup(() => { removeCommands(); commands.length = 0; });
        }
        let builtins;
        try { builtins = module.getBuiltInCommands(1, true, false); }
        catch { builtins = module.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = builtins.map(item => Number(item.id)).filter(Number.isFinite);
        Object.assign(command, {
            id: String(Math.min(-1, ...ids) - 1), applicationId: '-1', type: 1, inputType: 0,
            displayName: command.name, untranslatedName: command.name,
            displayDescription: command.description, untranslatedDescription: command.description,
        });
        for (const option of command.options ?? []) {
            option.displayName = option.name;
            option.displayDescription = option.description;
        }
        const execute = command.execute;
        command.execute = (...args) => {
            Promise.resolve().then(() => execute(...args)).catch(error => {
                console.error('Flarya command failed', error);
                showToast(String(error));
            });
        };
        commands.push(command);
        return () => { const index = commands.indexOf(command); if (index >= 0) commands.splice(index, 1); };
    }
    return {
        logger: console,
        metro: {
            findByProps, findByName, findByStoreName, findByTypeNameAll, findAll,
            common: {
                React: v.react.React, ReactNative: v.react.ReactNative,
                constants: v.discord.common.constants.Constants,
                FluxDispatcher: v.discord.common.flux.Dispatcher,
                clipboard: v.externals.ReactNativeClipboard.Clipboard,
            },
        },
        patcher: { before, after },
        plugin: { storage: observable(state) },
        storage: { useProxy },
        utils: { findInReactTree },
        commands: { registerCommand },
        ui: { assets: { getAssetIDByName: v.assets.getAssetIdByName }, toasts: { showToast } },
        flush: () => writes,
    };
}

let legacy;
let compatibility;
return { default: plugin({
    jsonStorage: { default: {} },
    async start(api) {
        await api.jsonStorage.get();
        const vendetta = compatibility = createCompatibility(api);
        legacy = ((function(H,K,E,c,g,S,d,bt,Y){"use strict";const q=c.findByProps("getCurrentUser","getUser"),D=c.findByProps("getMessages"),z=c.findByProps("getChannelId","getVoiceChannelId"),Et=c.findByProps("getTypingUsers"),h=c.findByProps("getVoiceStatesForChannel"),Jt=c.findByProps("getLocalVolume"),At=c.findByProps("setLocalVolume"),T=c.findByProps("isLocalSoundboardMuted"),Ct=c.findByProps("fetchMessages"),b=c.findByStoreName("ChannelStore"),N=c.findByStoreName("PrivateChannelSortStore"),P=c.findByStoreName("ChannelMemberStore"),Qt=c.findByStoreName("ThreadMemberListStore");c.findByStoreName("UserGuildSettingsStore"),c.findByProps("updateChannelOverrideSettings");const wt=c.findByProps("ignoreUser")??c.findByProps("unignoreUser"),Mt=c.findByProps("get","post","put","del"),J=new Map,U=new Map,B=new Map,v=new Map,Bt=new WeakMap;let m=[],R=[],L,Q=new WeakSet,X=0,Z=0,tt,et=new WeakSet,nt=0,rt=0,ut,ot=new WeakSet,it=new WeakSet,st,at,k=!1;const V=new Set;function l(){return d.storage.users??=[],typeof d.storage.users=="string"&&(d.storage.users=d.storage.users.match(/\d{17,20}/g)??[]),[...new Set(d.storage.users.map(String).filter(function(t){return/^\d{17,20}$/.test(t)}))]}function f(t){return typeof t=="string"&&l().includes(t)}function a(t){if(typeof t=="string")return t.match(/\d{17,20}/)?.[0];if(!(!t||typeof t!="object"))return a(t.value)??a(t.id)??a(t.user?.id)??a(t.member?.user?.id)}function It(t){for(const e of t??[]){const n=a(e);if(n)return n}}function G(t){const e=q?.getUser?.(t);return e?`${e.globalName??e.username} (${t})`:t}function vt(t){Y.showToast(t,bt.getAssetIDByName("Check"))}function x(t){Y.showToast(t,bt.getAssetIDByName("Small"))}function Xt(){return d.storage.ignoredUsers??=[],typeof d.storage.ignoredUsers=="string"&&(d.storage.ignoredUsers=d.storage.ignoredUsers.match(/\d{17,20}/g)??[]),[...new Set(d.storage.ignoredUsers.map(String).filter(function(t){return/^\d{17,20}$/.test(t)}))]}async function ct(t,e){if(V.has(t))return;const n=new Set(Xt());if(!(e&&n.has(t))&&!(!e&&!n.has(t))){V.add(t);try{const r=e?wt?.ignoreUser:wt?.unignoreUser;if(typeof r=="function")await r(t);else{const u=`/users/@me/relationships/${t}/ignore`;e?await Mt?.put?.({url:u}):await Mt?.del?.({url:u})}e?n.add(t):n.delete(t),d.storage.ignoredUsers=[...n]}catch(r){E.logger.warn(`Failed to ${e?"ignore":"unignore"} user`,r)}finally{V.delete(t)}}}function Ot(){return d.storage.voiceVolumes??={},d.storage.voiceVolumes}function _t(){return d.storage.soundboardMutes??={},d.storage.soundboardMutes}function ft(t){try{const e=Ot();t in e||(e[t]=Jt?.getLocalVolume?.(t)??100),At?.setLocalVolume?.(t,0)}catch(e){E.logger.warn("Failed to mute blocked voice user",e)}try{if(!T?.isLocalSoundboardMuted||!g.FluxDispatcher?.dispatch)return;const e=_t();t in e||(e[t]=!!T.isLocalSoundboardMuted(t)),T.isLocalSoundboardMuted(t)||g.FluxDispatcher.dispatch({type:"AUDIO_TOGGLE_LOCAL_SOUNDBOARD_MUTE",userId:t})}catch(e){E.logger.warn("Failed to mute blocked Soundboard user",e)}}function jt(t){try{const e=Ot();At?.setLocalVolume?.(t,e[t]??100),delete e[t]}catch(e){E.logger.warn("Failed to restore voice volume",e)}try{const e=_t();!e[t]&&T?.isLocalSoundboardMuted?.(t)&&g.FluxDispatcher.dispatch({type:"AUDIO_TOGGLE_LOCAL_SOUNDBOARD_MUTE",userId:t}),delete e[t]}catch(e){E.logger.warn("Failed to restore Soundboard state",e)}}function Zt(t){return t?.referenced_message?.author?.id??t?.referencedMessage?.author?.id}function te(t){return!t||!f(Zt(t))?t:{...t,referenced_message:null,referencedMessage:null,message_reference:null,messageReference:null}}function ee(t){if(!t||typeof t!="object")return t;let e=!1,n=t.content;if(typeof n=="string"){const u=n.replace(/<@!?(\d{17,20})>/g,function(o,i){return f(i)?(e=!0,""):o});u!==n&&(n=u)}let r=t.mentions;if(Array.isArray(r)){const u=r.filter(function(o){return!f(o?.id)});u.length!==r.length&&(r=u,e=!0)}return e?{...t,content:n,mentions:r}:t}function $(t){return ee(te(t))}function Ft(t){if(Array.isArray(t))return t;if(Array.isArray(t?._array))return t._array;if(Array.isArray(t?.toArray?.()))return t.toArray()}function Dt(t){return t.filter(function(e){return!f(e?.author?.id)}).map($)}function ne(t){if(Array.isArray(t))return Dt(t);if(!t||typeof t!="object")return t;const e=Bt.get(t);if(e)return e;const n=new Proxy(t,{get(r,u){const o=Ft(r);if(!o){const F=Reflect.get(r,u,r);return typeof F=="function"?F.bind(r):F}const i=Dt(o);if(u==="_array")return i;if(u==="length"||u==="size")return i.length;if(u==="toArray")return function(){return i};if(u===Symbol.iterator||u==="values")return i.values.bind(i);if(u==="map"||u==="filter"||u==="forEach"||u==="at")return i[u].bind(i);if(u==="first")return function(){return i[0]};if(u==="last")return function(){return i[i.length-1]};const p=Reflect.get(r,u,r);return typeof p=="function"?p.bind(r):p}});return Bt.set(t,n),n}function dt(t){const e=t?.author?.id;if(!e||!t?.id)return;let n=v.get(e);n||v.set(e,n=new Map),n.set(t.id,t)}function Tt(t){const e=v.get(t);if(v.delete(t),!!e)for(const n of[...e.values()].sort(function(r,u){try{return BigInt(r.id)<BigInt(u.id)?-1:1}catch{return 0}}))g.FluxDispatcher.dispatch({type:"MESSAGE_CREATE",channelId:n.channel_id??n.channelId,message:n,optimistic:!1,isPushNotification:!1,isHistory:!0,blacklistLocal:!0})}function Nt(t){try{const e=z?.getChannelId?.(),n=Ft(D?.getMessages?.(e));if(!e||!n)return;for(const r of n){if(r?.author?.id===t){dt(r);continue}const u=$(r);u!==r&&g.FluxDispatcher.dispatch({type:"MESSAGE_UPDATE",channelId:e,message:u,blacklistLocal:!0})}D?.emitChange?.()}catch(e){E.logger.warn("Failed to remove already mounted messages",e)}}async function re(){const t=z?.getChannelId?.();if(t)try{await Ct?.fetchMessages?.({channelId:t})}catch{try{await Ct?.fetchMessages?.(t)}catch(e){E.logger.warn("Failed to refresh messages after unblock",e)}}}function W(t){return[...Array.isArray(t?.recipients)?t.recipients:[],...Array.isArray(t?.rawRecipients)?t.rawRecipients:[],t?.getRecipientId?.()].map(function(e){return typeof e=="string"?e:e?.id}).filter(Boolean)}function Pt(t,e=0,n=new Set){if(!t||typeof t!="object"||e>5||n.has(t))return;n.add(t);const r=a(t.userId)??a(t.user_id)??a(t.user?.id)??a(t.member?.userId)??a(t.member?.user_id)??a(t.member?.id)??a(t.member?.user?.id)??a(t.item?.userId)??a(t.item?.user_id)??a(t.item?.user?.id)??a(t.row?.userId)??a(t.row?.user_id)??a(t.row?.user?.id)??a(t.data?.userId)??a(t.data?.user_id)??a(t.data?.user?.id)??a(t.guildMember?.userId)??a(t.guildMember?.user_id)??a(t.guildMember?.user?.id);if(r)return r;for(const[u,o]of Object.entries(t)){if(!/user|member|item|row|data|record|entry|payload/i.test(u))continue;if(typeof o=="string"){const p=a(o);if(p)return p}const i=Pt(o,e+1,n);if(i)return i}}function Ut(t,e){return!t||typeof t!="object"||Q.has(t)||typeof t[e]!="function"?!1:(Q.add(t),m.push(S.after(e,t,function([n],r){Z++,tt=n;const u=Pt(n);return u&&f(u)?null:r})),X++,!0)}function Rt(){try{const t=c.findByName("GuildChannelMemberRow",!1);if(t&&typeof t=="object")for(const e of Object.keys(t))(t[e]?.name==="GuildChannelMemberRow"||e==="default")&&Ut(t,e)}catch{}try{for(const t of c.findByTypeNameAll("GuildChannelMemberRow"))t?.type?.name==="GuildChannelMemberRow"&&Ut(t,"type")}catch{}}function C(t){return t?.name??t?.displayName??t?.type?.name??t?.type?.displayName}function Lt(t,e=0,n=new Set){if(!(!t||typeof t!="object"||e>5||n.has(t))){if(n.add(t),t.author?.id&&(t.id||t.channel_id||t.channelId))return t;for(const[r,u]of Object.entries(t)){if(!/message|item|data|record|entry|row|payload/i.test(r))continue;const o=Lt(u,e+1,n);if(o)return o}}}function lt(t,e){return!t||typeof t!="object"||ot.has(t)||typeof t[e]!="function"?!1:(ot.add(t),m.push(S.after(e,t,function([n],r){const u=Lt(n);return u&&f(u.author?.id)?null:r})),!0)}function kt(){const t=new Set(["Message","MessageRow","MessageListItem","MessageContent","MessageItem","ChatMessage"]);try{for(const e of c.findAll(function(n){return t.has(C(n))}))if(!(!e||typeof e!="object"))for(const n of Object.keys(e))(t.has(C(e[n]))||n==="default"&&typeof e[n]=="function")&&lt(e,n)}catch{}for(const e of t){try{const n=c.findByName(e,!1);if(n&&typeof n=="object")for(const r of Object.keys(n))(C(n[r])===e||r==="default"&&typeof n[r]=="function")&&lt(n,r)}catch{}try{for(const n of c.findByTypeNameAll(e))C(n?.type)===e&&lt(n,"type")}catch{}}}function ue(){const t=new Map;for(const e of["getSortedPrivateChannels","getPrivateChannels","getMutablePrivateChannels"])try{const n=b?.[e]?.(),r=Array.isArray(n)?n:n instanceof Map?[...n.values()]:n&&typeof n=="object"?Object.values(n):[];for(const u of r){const o=typeof u=="string"?b?.getChannel?.(u):u;o?.id&&t.set(o.id,o)}}catch{}return[...t.values()]}function Vt(t){const e=ue().filter(function(n){return(n?.type===1||n?.isDM?.())&&W(n).includes(t)});try{const n=b?.getDMFromUserId?.(t),r=typeof n=="string"?b?.getChannel?.(n):n;r?.id&&!e.some(function(u){return u.id===r.id})&&e.push(r)}catch{}return e}function O(t,e=Vt(t)){for(const n of e)J.set(t,n);_()}function Gt(t){J.delete(t),_()}function w(t){const e=typeof t=="string"?b?.getChannel?.(t):t;return!!e&&(e.type===1||e.isDM?.())&&W(e).some(f)}function xt(t,e=0,n=new Set){if(!(!t||typeof t!="object"||e>5||n.has(t))){if(n.add(t),w(t))return t;for(const[r,u]of Object.entries(t)){if(!/channel|item|data|record|entry|row|payload/i.test(r))continue;if(typeof u=="string"){const i=b?.getChannel?.(u);if(w(i))return i}const o=xt(u,e+1,n);if(o)return o}}}function yt(t,e){return!t||typeof t!="object"||it.has(t)||typeof t[e]!="function"?!1:(it.add(t),m.push(S.after(e,t,function([n],r){return xt(n)?null:r})),!0)}function $t(){const t=new Set(["DMRow","GroupDMRow","HomeDrawerDMsRowWrapper","ChannelRow","ChannelRowItem","BaseChannelItem"]);try{for(const e of c.findAll(function(n){return t.has(C(n))}))if(!(!e||typeof e!="object"))for(const n of Object.keys(e))(t.has(C(e[n]))||n==="default"&&typeof e[n]=="function")&&yt(e,n)}catch{}for(const e of t){try{const n=c.findByName(e,!1);if(n&&typeof n=="object")for(const r of Object.keys(n))(C(n[r])===e||r==="default"&&typeof n[r]=="function")&&yt(n,r)}catch{}try{for(const n of c.findByTypeNameAll(e))C(n?.type)===e&&yt(n,"type")}catch{}}}function oe(t){if(Array.isArray(t))return t.filter(function(r){return!w(r)});if(t instanceof Map)return new Map([...t.entries()].filter(function([r,u]){return!w(u)&&!w(r)}));if(!t||typeof t!="object")return t;let e=!1;const n={...t};for(const[r,u]of Object.entries(n))if(w(u)||w(r))delete n[r],e=!0;else if(Array.isArray(u)){const o=u.filter(function(i){return!w(i)});o.length!==u.length&&(n[r]=o,e=!0)}return e?n:t}function Wt(t){try{return st?.(t)}catch{return}}function ie(t){return!t||typeof t!="object"?[]:Array.isArray(t)?t:t instanceof Map?[...t.values()]:Object.values(t)}function pt(t){if(!t)return;const e=B.get(t);B.delete(t),e&&g.FluxDispatcher.dispatch({type:"CHANNEL_CREATE",channel:e})}function Ht(t){if(!t||B.has(t))return;let e=[];try{e=ie(at?.(t))}catch{}if(e.some(function(r){return!f(M(r))}))return;const n=b?.getChannel?.(t);n&&(B.set(t,n),g.FluxDispatcher.dispatch({type:"CHANNEL_DELETE",channel:n}))}function Kt(t,e=Wt(t)){!e||!(e.channelId??e.channel_id)||(U.set(t,{...e}),g.FluxDispatcher.dispatch({type:"VOICE_STATE_UPDATES",voiceStates:[{...e,channelId:null,channel_id:null}]}),Ht(e.channelId??e.channel_id))}function Yt(t){const e=U.get(t);U.delete(t),e&&(pt(e.channelId??e.channel_id),g.FluxDispatcher.dispatch({type:"VOICE_STATE_UPDATES",voiceStates:[e]}))}function _(){N?.emitChange?.(),b?.emitChange?.();try{P?.doEmitChanges?.()}catch{}h?.emitChange?.();try{h?.doEmitChanges?.()}catch{}}function M(t){return a(t?.userId)??a(t?.user_id)??a(t?.user?.id)??a(t?.member?.userId)??a(t?.member?.user?.id)??a(t?.voiceState?.userId)??a(t?.voiceState?.user_id)??a(t?.voiceState?.user?.id)??a(t?.participant?.userId)??a(t?.participant?.user?.id)}function j(t){if(!t||typeof t!="object")return t;if(f(M(t)))return;if(Array.isArray(t))return t.filter(function(n){return!f(M(n))}).map(j);if(t instanceof Map)return new Map([...t.entries()].filter(function([n,r]){return!f(n)&&!f(M(r))}).map(function([n,r]){return[n,j(r)]}));const e=Object.getPrototypeOf(t);return e!==Object.prototype&&e!==null?t:Object.fromEntries(Object.entries(t).filter(function([n,r]){return!f(n)&&!f(M(r))}).map(function([n,r]){return[n,j(r)]}))}function ht(t,e=0,n=new Set){if(t==null||e>20)return t;if(Array.isArray(t))return t.map(function(i){return ht(i,e+1,n)}).filter(function(i){return i!=null});if(typeof t!="object"||n.has(t))return t;n.add(t);const r=t.props;if(!r||typeof r!="object")return t;if(f(M(r)))return null;let u=!1;const o={...r};if("children"in r){const i=ht(r.children,e+1,n);i!==r.children&&(o.children=i,u=!0)}for(const i of["data","voiceStates","users","members","participants"]){if(!(i in r))continue;const p=j(r[i]);p!==r[i]&&(o[i]=p,u=!0)}return u?{...t,props:o}:t}function qt(t,e){return!t||typeof t!="object"||et.has(t)||typeof t[e]!="function"?!1:(et.add(t),m.push(S.after(e,t,function([n],r){return rt++,ut=n,ht(r)})),nt++,!0)}function zt(){try{const t=c.findByName("GuildVoiceChannelRow",!1);if(t&&typeof t=="object")for(const e of Object.keys(t))(t[e]?.name==="GuildVoiceChannelRow"||e==="default")&&qt(t,e)}catch{}try{for(const t of c.findByTypeNameAll("GuildVoiceChannelRow"))t?.type?.name==="GuildVoiceChannelRow"&&qt(t,"type")}catch{}}function se(t){if(!t||!Array.isArray(t.rows)||!Array.isArray(t.groups))return t;const e=new Map;let n;const r=t.rows.filter(function(o){return o?.type==="GROUP"?(n=o.id,e.set(n,0),!0):o?.type==="MEMBER"&&f(o.userId??o.user?.id)?!1:(n&&e.set(n,(e.get(n)??0)+1),!0)}).filter(function(o){return o?.type!=="GROUP"||(e.get(o.id)??0)>0}),u=t.groups.map(function(o){return{...o,count:e.get(o.id)??o.count,index:r.findIndex(function(i){return i?.type==="GROUP"&&i.id===o.id})}}).filter(function(o){return o.count>0&&o.index>=0});return{...t,groups:u,rows:r}}function ae(){m.push(S.before("dispatch",g.FluxDispatcher,function([t]){if(!t||typeof t!="object")return;if(t.type==="LOAD_MESSAGES_SUCCESS"&&Array.isArray(t.messages)){t.messages.filter(function(n){return f(n?.author?.id)}).forEach(dt),t.messages=t.messages.filter(function(n){return!f(n?.author?.id)}).map($);return}if((t.type==="MESSAGE_CREATE"||t.type==="MESSAGE_UPDATE")&&f(t.message?.author?.id)){dt(t.message),t.type="BLACKLIST_IGNORED_MESSAGE",t.message=null;return}if((t.type==="MESSAGE_CREATE"||t.type==="MESSAGE_UPDATE")&&t.message){t.message=$(t.message);return}if((t.type==="TYPING_START"||t.type==="TYPING_START_LOCAL")&&f(t.userId??t.user_id)){t.type="BLACKLIST_IGNORED_TYPING";return}const e=t.channel&&(t.channel.type===1||t.channel.isDM?.())&&W(t.channel).some(f);if(t.type==="CHANNEL_CREATE"&&e){const n=W(t.channel).find(f);n&&J.set(n,t.channel),setTimeout(_,0)}if(t.type==="VOICE_STATE_UPDATES"&&Array.isArray(t.voiceStates)){const n=new Set;t.voiceStates=t.voiceStates.map(function(r){const u=r?.userId??r?.user_id,o=r?.channelId??r?.channel_id;return f(u)?(o&&(U.set(u,{...r}),n.add(o)),ft(u),{...r,channelId:null,channel_id:null}):(o&&B.has(o)&&setTimeout(function(){return pt(o)},0),r)}),n.size&&setTimeout(function(){return n.forEach(Ht)},0)}(t.type==="CONNECTION_OPEN"||t.type==="CACHE_LOADED")&&(setTimeout(function(){return k&&l().forEach(function(n){return O(n)})},0),setTimeout(function(){return k&&l().forEach(function(n){return O(n)})},1500))}))}function ce(){D?.getMessages&&m.push(S.after("getMessages",D,function(t,e){return ne(e)}));for(const t of[N,b]){const e=new Set;let n=t;for(let r=0;n&&r<4;r++,n=Object.getPrototypeOf(n))for(const u of Reflect.ownKeys(n))typeof u=="string"&&/(private|direct).*channel|channel.*(private|direct)/i.test(u)&&typeof t?.[u]=="function"&&e.add(u);for(const r of e)m.push(S.after(r,t,function(u,o){return oe(o)}))}Et?.getTypingUsers&&m.push(S.after("getTypingUsers",Et,function(t,e){return!e||typeof e!="object"?e:Object.fromEntries(Object.entries(e).filter(function([n]){return!f(n)}))}));for(const t of["getVoiceStatesForChannel","getVoiceStates","getVoiceStatesForGuild","getVoiceStateForChannel","getAllVoiceStates","getVideoVoiceStatesForChannel","getVoiceState","getDiscoverableVoiceState","getVoiceStateForSession"])typeof h?.[t]=="function"&&m.push(S.after(t,h,function(e,n){return j(n)}));for(const t of["getVoiceStateForUser","getDiscoverableVoiceStateForUser","getUserVoiceChannelId"])typeof h?.[t]=="function"&&m.push(S.after(t,h,function(e,n){return e.some(function(r){return typeof r=="string"&&f(r)})||f(M(n))?void 0:n}));P?.getProps&&m.push(S.after("getProps",P,function(t,e){return se(e)}))}function fe(){const t=[{name:"user",description:"\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0438\u043B\u0438 \u0432\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u0435\u0433\u043E Discord ID",type:6,required:!1}],e={name:"user",description:"\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0438\u0437 \u0447\u0451\u0440\u043D\u043E\u0433\u043E \u0441\u043F\u0438\u0441\u043A\u0430",type:3,required:!0,choices:[]},n=function(){e.choices=l().map(function(r){const u=q?.getUser?.(r),o=u?.globalName??u?.username??r;return{name:o,displayName:o,label:o,value:r}})};n(),R.push(K.registerCommand({name:"block",description:"\u0421\u043A\u0440\u044B\u0442\u044C \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0438\u043B\u0438 \u043F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0441\u043F\u0438\u0441\u043E\u043A",options:t,execute:function(r){const u=It(r);if(!u){const p=l();Y.showToast(p.length?`\u0421\u043A\u0440\u044B\u0442\u043E: ${p.map(G).join(", ")}`:"\u0421\u043F\u0438\u0441\u043E\u043A \u043F\u0443\u0441\u0442");return}if(u===q?.getCurrentUser?.()?.id)return x("\u041D\u0435\u043B\u044C\u0437\u044F \u0441\u043A\u0440\u044B\u0442\u044C \u0441\u0430\u043C\u043E\u0433\u043E \u0441\u0435\u0431\u044F");if(f(u))return x(`${G(u)} \u0443\u0436\u0435 \u0441\u043A\u0440\u044B\u0442`);const o=Vt(u),i=Wt(u);d.storage.users=[...l(),u],n(),ct(u,!0),ft(u),Kt(u,i),Nt(u),O(u,o),_(),g.FluxDispatcher.dispatch({type:"BLACKLIST_REFRESH"}),vt(`${G(u)} \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D \u0432 \u0441\u043F\u0438\u0441\u043E\u043A`)}})),R.push(K.registerCommand({name:"unblock",description:"\u041F\u0435\u0440\u0435\u0441\u0442\u0430\u0442\u044C \u0441\u043A\u0440\u044B\u0432\u0430\u0442\u044C \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F",options:[e],execute:function(r){const u=It(r);if(!u)return x("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0438\u043B\u0438 \u0432\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u0435\u0433\u043E ID");if(!f(u))return x(`${G(u)} \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0432 \u0441\u043F\u0438\u0441\u043A\u0435`);d.storage.users=l().filter(function(o){return o!==u}),n(),ct(u,!1),Tt(u),jt(u),Yt(u),Gt(u),_(),setTimeout(function(){return void re()},600)}})),R.push(K.registerCommand({name:"blockdebug",description:"Copy Blacklist diagnostics for the current Discord screen",options:[],execute:function(r,u){const o=function(s,y=0){if(s==null||typeof s!="object")return s;if(y>2)return Array.isArray(s)?`[Array:${s.length}]`:"[Object]";if(Array.isArray(s))return s.slice(0,3).map(function(A){return o(A,y+1)});const I={};for(const A of Object.keys(s).slice(0,30))try{I[A]=o(s[A],y+1)}catch{I[A]="[Error]"}return I},i=function(s){return s?.name??s?.displayName??s?.type?.name??s?.type?.displayName},p=c.findAll(function(s){const y=i(s);return typeof y=="string"&&/member|channel.*detail|detail.*channel/i.test(y)}).map(i).filter(Boolean),F=c.findAll(function(s){const y=i(s);return typeof y=="string"&&/private.*channel|direct.*message|dm.*row|channel.*row|channel.*item/i.test(y)}).map(i).filter(Boolean),le=c.findAll(function(s){try{return typeof s?.getName=="function"&&/member/i.test(s.getName())}catch{return!1}}).map(function(s){return{name:s.getName(),methods:Object.keys(s).filter(function(y){return typeof s[y]=="function"}).slice(0,50)}});let gt,mt,St;try{gt=P?.getProps?.(u?.guild?.id,u?.channel?.id)}catch(s){gt=String(s)}try{mt=Qt?.getMemberListSections?.(u?.channel?.id)}catch(s){mt=String(s)}try{const s=z?.getVoiceChannelId?.();St={voiceChannelId:s,forChannel:o(h?.getVoiceStatesForChannel?.(s)),forGuild:o(h?.getVoiceStates?.(u?.guild?.id??u?.channel?.guild_id))}}catch(s){St=String(s)}const ye=JSON.stringify({blockedIds:l(),guildId:u?.guild?.id,channelId:u?.channel?.id,componentNames:[...new Set(p)],dmComponentNames:[...new Set(F)],membersPatch:{patchedComponents:X,renderCalls:Z,lastProps:o(tt)},voicePatch:{patchedComponents:nt,renderCalls:rt,lastProps:o(ut)},memberStores:le,channelMemberProps:o(gt),threadSections:o(mt),voiceStates:St,voiceStoreMethods:function(){const s=new Set;let y=h;for(let I=0;y&&I<4;I++,y=Object.getPrototypeOf(y))Reflect.ownKeys(y).forEach(function(A){return typeof A=="string"&&/voice|state/i.test(A)&&s.add(A)});return[...s]}(),channelStoreMethods:Object.keys(b??{}).filter(function(s){return/private|dm/i.test(s)}),privateSortMethods:Object.keys(N??{}).filter(function(s){return typeof N[s]=="function"})},null,2);g.clipboard.setString(ye),vt("\u0414\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430 Block \u0441\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u0432 \u0431\u0443\u0444\u0435\u0440")}}))}var de={onLoad(){k=!0,d.storage.users??=[],d.storage.ignoredUsers??=[],d.storage.voiceVolumes??={},d.storage.soundboardMutes??={},d.storage.dmNotificationSettings??={},st=h?.getVoiceStateForUser?.bind(h),at=h?.getVoiceStatesForChannel?.bind(h),ae(),ce(),Rt(),zt(),kt(),$t(),L=setInterval(function(){Rt(),zt(),kt(),$t(),l().forEach(function(t){return O(t)})},1e3),fe(),l().forEach(Nt),l().forEach(function(t){return void ct(t,!0)}),l().forEach(ft),l().forEach(function(t){return Kt(t)}),l().forEach(function(t){return O(t)}),E.logger.log("Blacklist loaded")},onUnload(){k=!1,R.splice(0).forEach(function(t){return t()}),L&&clearInterval(L),L=void 0,m.splice(0).reverse().forEach(function(t){return t()}),l().forEach(Tt),v.clear(),Q=new WeakSet,et=new WeakSet,ot=new WeakSet,it=new WeakSet,X=0,Z=0,tt=void 0,nt=0,rt=0,ut=void 0,l().forEach(Gt),l().forEach(Yt),[...B.keys()].forEach(pt),st=void 0,at=void 0,V.clear(),l().forEach(jt),E.logger.log("Blacklist unloaded")}};return H.default=de,Object.defineProperty(H,"__esModule",{value:!0}),H})({},vendetta.commands,vendetta,vendetta.metro,vendetta.metro.common,vendetta.patcher,vendetta.plugin,vendetta.ui.assets,vendetta.ui.toasts)).default;
        api.cleanup(async () => {
            try { legacy.onUnload?.(); }
            finally { legacy = undefined; await compatibility.flush(); }
        });
        legacy.onLoad?.();
    },
    SettingsComponent() {
        return legacy?.settings ? valenced.react.React.createElement(legacy.settings) : null;
    },
}) };
})()
