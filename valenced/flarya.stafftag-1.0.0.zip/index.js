(function () {
// Scoped adapter for the published Revenge bundles; no global vendetta dependency
function createCompatibility(api) {
    const v = api.unscoped;
    const { lookupModule, lookupModules, filters } = v.modules.finders;
    let filterId = 0;
    function matching(predicate) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(value && predicate(value)),
            () => `flarya.compat.${++filterId}`,
        )();
    }
    const findByProps = (...props) => lookupModule(filters.withProps(...props))[0];
    const findByName = (name, defaultExport = true) =>
        lookupModule(filters.withName(name), { returnNamespace: !defaultExport })[0];
    const findAll = predicate => [...lookupModules(matching(predicate))].map(([value]) => value);
    const findByStoreName = name => lookupModule(matching(value => value.getName?.() === name))[0];
    const findByTypeNameAll = name => findAll(value => value.type?.name === name);

    // Vendetta after hooks receive arguments and keep the result on undefined
    const after = (key, parent, hook) => v.patcher.instead(parent, key, function (args, original) {
        const result = original.apply(this, args);
        const replacement = hook.call(this, args, result);
        return replacement === undefined ? result : replacement;
    });
    const before = (key, parent, hook) => v.patcher.before(parent, key, args => hook(args) ?? args);

    const state = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const listeners = new Set();
    const proxies = new WeakMap();
    let writes = Promise.resolve();
    function persist() {
        const snapshot = JSON.parse(JSON.stringify(state));
        writes = writes.then(() => api.jsonStorage.set(snapshot, true));
        // Report storage failures while keeping later updates writable
        writes = writes.catch(error => console.error('Flarya plugin storage', error));
        for (const listener of listeners) listener();
    }
    function observable(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get(target, key) { return observable(target[key]); },
            set(target, key, next) { target[key] = next; persist(); return true; },
            deleteProperty(target, key) { delete target[key]; persist(); return true; },
        });
        proxies.set(value, proxy);
        return proxy;
    }
    function useProxy() {
        const [, render] = v.react.React.useReducer(n => n + 1, 0);
        v.react.React.useEffect(() => {
            listeners.add(render);
            return () => listeners.delete(render);
        }, []);
    }
    function findInReactTree(root, predicate) {
        const seen = new Set();
        function visit(node) {
            if (!node || typeof node !== 'object' || seen.has(node)) return;
            seen.add(node);
            if (predicate(node)) return node;
            const children = Array.isArray(node) ? node : [node.props?.children];
            for (const child of children) {
                const result = visit(child);
                if (result) return result;
            }
        }
        return visit(root);
    }
    function showToast(text, icon) {
        const toasts = v.discord.actions.ToastActionCreators;
        const key = `flarya-${Date.now()}`;
        if (toasts.open.length === 1) toasts.open({ key, content: text, icon });
        else toasts.open(key, { text, icon });
    }
    const commands = [];
    let removeCommands;
    function registerCommand(command) {
        const module = findByProps('getBuiltInCommands');
        if (!module) throw new Error('Discord command API is unavailable');
        if (!removeCommands) {
            removeCommands = after('getBuiltInCommands', module, ([types], result) => [
                ...result,
                ...commands.filter(item => (Array.isArray(types) ? types : [types]).includes(item.type)),
            ]);
            api.cleanup(() => { removeCommands(); commands.length = 0; });
        }
        let builtins;
        try { builtins = module.getBuiltInCommands(1, true, false); }
        catch { builtins = module.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = builtins.map(item => Number(item.id)).filter(Number.isFinite);
        Object.assign(command, {
            id: String(Math.min(-1, ...ids) - 1), applicationId: '-1', type: 1, inputType: 0,
            displayName: command.name, untranslatedName: command.name,
            displayDescription: command.description, untranslatedDescription: command.description,
        });
        for (const option of command.options ?? []) {
            option.displayName = option.name;
            option.displayDescription = option.description;
        }
        const execute = command.execute;
        command.execute = (...args) => {
            Promise.resolve().then(() => execute(...args)).catch(error => {
                console.error('Flarya command failed', error);
                showToast(String(error));
            });
        };
        commands.push(command);
        return () => { const index = commands.indexOf(command); if (index >= 0) commands.splice(index, 1); };
    }
    return {
        logger: console,
        metro: {
            findByProps, findByName, findByStoreName, findByTypeNameAll, findAll,
            common: {
                React: v.react.React, ReactNative: v.react.ReactNative,
                constants: v.discord.common.constants.Constants,
                FluxDispatcher: v.discord.common.flux.Dispatcher,
                clipboard: v.externals.ReactNativeClipboard.Clipboard,
            },
        },
        patcher: { before, after },
        plugin: { storage: observable(state) },
        storage: { useProxy },
        utils: { findInReactTree },
        commands: { registerCommand },
        ui: { assets: { getAssetIDByName: v.assets.getAssetIdByName }, toasts: { showToast } },
        flush: () => writes,
    };
}

let legacy;
let compatibility;
return { default: plugin({
    jsonStorage: { default: {} },
    async start(api) {
        await api.jsonStorage.get();
        const vendetta = compatibility = createCompatibility(api);
        legacy = ((function(P,u,t,O,d,z,H){"use strict";let w=[],F;const U=new Set(["BOT","APP","SYSTEM","SERVER","AI","AUTOMOD"]),W=[{text:"OWNER",color:"#f0b232",owner:!0},{text:"ADMIN",color:"#ed4245",permissions:["ADMINISTRATOR"]},{text:"STAFF",color:"#57f287",permissions:["MANAGE_GUILD","MANAGE_CHANNELS","MANAGE_ROLES","MANAGE_WEBHOOKS"]},{text:"MOD",color:"#5865f2",permissions:["MANAGE_MESSAGES","KICK_MEMBERS","BAN_MEMBERS"]},{text:"VC MOD",color:"#00a8fc",permissions:["MOVE_MEMBERS","MUTE_MEMBERS","DEAFEN_MEMBERS"]},{text:"CHAT MOD",color:"#9b59b6",permissions:["MODERATE_MEMBERS"]}];function $(){z.useProxy(d.storage);const e=t.ReactNative?.View,a=t.ReactNative?.Text,r=t.ReactNative?.Switch;if(!e||!a||!r||typeof t.React?.createElement!="function")return null;const c=function(f,o,s){return t.React.createElement(e,{key:s,style:{minHeight:82,flexDirection:"row",alignItems:"center"}},t.React.createElement(e,{style:{flex:1,paddingRight:12}},t.React.createElement(a,{style:{color:"white",fontSize:17,fontWeight:"600"}},f),t.React.createElement(a,{style:{color:"#B5BAC1",fontSize:14,marginTop:4}},o)),t.React.createElement(r,{value:Boolean(d.storage[s]),onValueChange:function(n){d.storage[s]=n}}))};return t.React.createElement(e,{style:{paddingHorizontal:16,paddingVertical:12}},t.React.createElement(a,{style:{color:"#B5BAC1",fontSize:22,fontWeight:"700",marginBottom:2}},"Settings"),c("Use Role Color","Use the member's role color for the tag","useRoleColor"),c("Show In Chat","Show staff tags next to names in chat","showInChat"),c("Show In Member List","Show staff tags in the server member list","showInMemberList"))}function j(e,a){try{return(BigInt(e)&BigInt(a))!==0n}catch{return!1}}function k(e,a,r,c,f){if(!e||!r||r.bot)return;let o;try{o=c?.computePermissions?.({user:r,context:e,overwrites:a?.permissionOverwrites})}catch{}return W.find(function(s){return s.owner&&(e.ownerId??e.owner_id)===r.id||"permissions"in s&&s.permissions.some(function(n){return j(o,f[n])})})}function D(e){if(typeof e=="string"&&e)return e.startsWith("#")?e:void 0;if(typeof e=="number"&&e>0)return`#${e.toString(16).padStart(6,"0").slice(-6)}`}function L(e,a="#5865f2"){let r,c,f;if(typeof e=="number"){const o=e>>>0;r=o>>16&255,c=o>>8&255,f=o&255}else{const o=(typeof e=="string"?e:a).match(/^#([\da-f]{3}|[\da-f]{6})$/i);if(o){const s=o[1].length===3?[...o[1]].map(function(n){return n+n}).join(""):o[1];r=parseInt(s.slice(0,2),16),c=parseInt(s.slice(2,4),16),f=parseInt(s.slice(4,6),16)}}return r==null||c==null||f==null?"#FFFFFF":(r*299+c*587+f*114)/255e3>.62?"#111111":"#FFFFFF"}function V(e,a,r){const c=[a?.colorString,a?.color,r?.colorString,r?.nameColor,r?.color].map(D).find(Boolean);if(c)return c;const f=a?.roles??a?.roleIds??r?.roles??r?.roleIds;if(!Array.isArray(f))return;const o=e?.roles??e?.roleMap,s=f.map(function(n){return o?.[n]??o?.get?.(n)}).filter(function(n){return n&&(n.color||n.colorString)}).sort(function(n,m){return(m.position??0)-(n.position??0)});return D(s[0]?.colorString)??D(s[0]?.color)}function K(){const e=u.findByName("getTagProperties",!1),a=u.findByStoreName("GuildStore"),r=u.findByStoreName("ChannelStore"),c=u.findByProps("getMember","getMembers")??u.findByStoreName("GuildMemberStore"),f=u.findByProps("computePermissions","canEveryoneRole"),o=t.constants?.Permissions??{};typeof e?.default=="function"&&w.push(O.after("default",e,function(s,n){try{const m=s?.[0],C=m?.message??m,S=C?.author;if(d.storage.showInChat===!1||!n||!S||S.bot||U.has(String(n.tagText).toUpperCase()))return;const i=r?.getChannel?.(C.channel_id??C.channelId),l=a?.getGuild?.(i?.guild_id??i?.guildId),g=k(l,i,S,f,o);if(!g)return;const E=c?.getMember?.(l.id,S.id),h=d.storage.useRoleColor?V(l,E)??g.color:g.color,p=t.ReactNative?.processColor;return{...n,tagText:g.text,tagTextColor:typeof p=="function"?p(L(h)):void 0,tagBackgroundColor:typeof p=="function"?p(h):void 0,tagVerified:!1,tagType:void 0}}catch{return}}))}function J(){const e=u.findByStoreName("GuildStore"),a=u.findByStoreName("ChannelStore"),r=u.findByProps("getMember","getMembers")??u.findByStoreName("GuildMemberStore"),c=u.findByProps("getRole","getRoles")??u.findByStoreName("GuildRoleStore"),f=u.findByProps("computePermissions","canEveryoneRole"),o=t.constants?.Permissions??{},s=t.ReactNative?.View,n=t.ReactNative?.Text;if(!(!s||!n||typeof t.React?.createElement!="function")){for(const m of u.findByTypeNameAll("UserRow"))typeof m?.type=="function"&&w.push(O.after("type",m,function(C,S){try{const i=C?.[0],l=i?.user,g=i?.guildId??i?.guild_id;if(d.storage.showInMemberList===!1||!S||!l||!g)return;const E=e?.getGuild?.(g),h=k(E,void 0,l,f,o);if(!h)return;const p=S?.props?.label??S,T=H.findInReactTree(p,function(y){return Array.isArray(y?.props?.children)&&y.props.children.some(function(R){return typeof R=="string"||typeof R?.props?.children=="string"})});if(!T?.props||T.props.children.some(function(y){return y?.props?.staffTagsText}))return;const M=r?.getMember?.(E.id,l.id)??i?.member??i?.guildMember,I=d.storage.useRoleColor?V(E,M,i)??h.color:h.color,b=t.ReactNative?.processColor,A=t.ReactNative?.StyleSheet?.flatten,_=d.storage.useRoleColor&&H.findInReactTree(p,function(y){try{const R=typeof A=="function"?A(y?.props?.style):y?.props?.style,G=y?.props?.children,Z=[M?.nick,i?.name,l?.globalName,l?.username].filter(Boolean);return typeof G=="string"&&Z.includes(G)&&R?.color!=null}catch{return!1}});let B;try{B=(typeof A=="function"?A(_?.props?.style):_?.props?.style)?.color}catch{}const x=i?.nameColor??i?.usernameColor??i?.colorString??i?.color;let v;if(d.storage.useRoleColor&&!B&&x==null&&Array.isArray(M?.roles)){const y=M.roles.map(function(R){return c?.getRole?.(E.id,R)}).filter(function(R){return R&&(R.colorString||R.color)}).sort(function(R,G){return(G.position??0)-(R.position??0)})[0];v=y?.colorString??(y?.color?`#${y.color.toString(16).padStart(6,"0")}`:void 0)}const N=B??x??M?.colorString??v,X=d.storage.useRoleColor&&N!=null?N:typeof b=="function"?b(I):I,Y=L(N??I,I);T.props.children.push(t.React.createElement(s,{key:`staff-tags-${l.id}`,staffTagsText:h.text,style:{marginLeft:4,paddingHorizontal:4,height:18,minHeight:18,borderRadius:4,backgroundColor:X,alignItems:"center",justifyContent:"center",alignSelf:"center",flexShrink:0,overflow:"visible"}},t.React.createElement(n,{style:{color:Y,fontSize:11,fontWeight:"700",lineHeight:15,includeFontPadding:!1,textAlignVertical:"center"}},h.text)))}catch{return}}));for(const m of u.findByTypeNameAll("MessageRow"))typeof m?.type=="function"&&w.push(O.after("type",m,function(C,S){try{if(d.storage.showInChat===!1||!S)return;const i=C?.[0],l=i?.message??i?.item?.message??i?.content?.message,g=l?.author;if(!l||!g)return;const E=a?.getChannel?.(l.channel_id??l.channelId??i?.channelId),h=e?.getGuild?.(E?.guild_id??E?.guildId??i?.guildId),p=k(h,E,g,f,o);if(!p)return;const T=[l?.member?.nick,g?.globalName,g?.username].filter(Boolean),M=H.findInReactTree(S,function(B){const x=B?.props?.children;return Array.isArray(x)?x.some(function(v){const N=typeof v=="string"?v:v?.props?.children;return typeof N=="string"&&T.includes(N)}):!1});if(!M?.props||M.props.children.some(function(B){return B?.props?.staffTagsText}))return;const I=l?.member??r?.getMember?.(h?.id,g.id),b=d.storage.useRoleColor?V(h,I)??p.color:p.color,A=t.ReactNative?.processColor,_=typeof A=="function"?A(b):b;M.props.children.push(t.React.createElement(s,{key:`staff-tags-chat-${l.id}`,staffTagsText:p.text,style:{marginLeft:4,paddingHorizontal:4,height:18,minHeight:18,borderRadius:4,backgroundColor:_,alignItems:"center",justifyContent:"center",alignSelf:"center",flexShrink:0,overflow:"visible"}},t.React.createElement(n,{style:{color:L(b),fontSize:11,fontWeight:"700",lineHeight:15,includeFontPadding:!1,textAlignVertical:"center"}},p.text)))}catch{return}}))}}var Q={onLoad:function(){d.storage.useRoleColor??=!0,d.storage.showInChat??=!0,d.storage.showInMemberList??=!0,F=setTimeout(function(){try{K()}catch{}try{J()}catch{}},1500)},onUnload:function(){F&&clearTimeout(F),F=void 0;for(const e of w.splice(0).reverse())try{e()}catch{}},settings:$};return P.default=Q,Object.defineProperty(P,"__esModule",{value:!0}),P})({},vendetta.metro,vendetta.metro.common,vendetta.patcher,vendetta.plugin,vendetta.storage,vendetta.utils)).default;
        api.cleanup(async () => {
            try { legacy.onUnload?.(); }
            finally { legacy = undefined; await compatibility.flush(); }
        });
        legacy.onLoad?.();
    },
    SettingsComponent() {
        return legacy?.settings ? valenced.react.React.createElement(legacy.settings) : null;
    },
}) };
})()
