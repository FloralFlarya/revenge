(function () {
// Scoped adapter for the published Revenge bundles; no global vendetta dependency
function createCompatibility(api) {
    const v = api.unscoped;
    const { lookupModule, lookupModules, filters } = v.modules.finders;
    // These lookups always scan fresh exports, including modules loaded after startup
    // Keep a bounded set of cache keys because Staff Tags retries as screens load
    function matching(predicate, key = 'scan') {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(value && predicate(value)),
            () => `flarya.compat.${key}`,
        )();
    }
    const findByProps = (...props) => lookupModule(filters.withProps(...props), { cached: false })[0];
    const findByName = (name, defaultExport = true) =>
        lookupModule(filters.withName(name), { returnNamespace: !defaultExport, cached: false })[0];
    const findAll = predicate => [...lookupModules(matching(predicate), { cached: false })].map(([value]) => value);
    const findByStoreName = name => lookupModule(matching(value => typeof value.getName === 'function' && value.getName() === name, `store.${name}`), { cached: false })[0];
    const findByTypeNameAll = name => [...lookupModules(matching(value => value.type?.name === name, `type.${name}`), { cached: false })].map(([value]) => value);

    // Vendetta after hooks receive arguments and keep the result on undefined
    const after = (key, parent, hook) => v.patcher.instead(parent, key, function (args, original) {
        const result = original.apply(this, args);
        const replacement = hook.call(this, args, result);
        return replacement === undefined ? result : replacement;
    });
    const before = (key, parent, hook) => v.patcher.before(parent, key, args => hook(args) ?? args);

    const state = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const listeners = new Set();
    const proxies = new WeakMap();
    let writes = Promise.resolve();
    function persist() {
        const snapshot = JSON.parse(JSON.stringify(state));
        writes = writes.then(() => api.jsonStorage.set(snapshot, true));
        // Report storage failures while keeping later updates writable
        writes = writes.catch(error => console.error('Flarya plugin storage', error));
        for (const listener of listeners) listener();
    }
    function observable(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get(target, key) { return observable(target[key]); },
            set(target, key, next) { target[key] = next; persist(); return true; },
            deleteProperty(target, key) { delete target[key]; persist(); return true; },
        });
        proxies.set(value, proxy);
        return proxy;
    }
    function useProxy() {
        const [, render] = v.react.React.useReducer(n => n + 1, 0);
        v.react.React.useEffect(() => {
            listeners.add(render);
            return () => listeners.delete(render);
        }, []);
    }
    function findInReactTree(root, predicate) {
        const seen = new Set();
        function visit(node) {
            if (!node || typeof node !== 'object' || seen.has(node)) return;
            seen.add(node);
            if (predicate(node)) return node;
            const children = Array.isArray(node) ? node : [node.props?.children, node.props?.label, node.props?.title];
            for (const child of children) {
                const result = visit(child);
                if (result) return result;
            }
        }
        return visit(root);
    }
    function showToast(text, icon) {
        const toasts = v.discord.actions.ToastActionCreators;
        const key = `flarya-${Date.now()}`;
        if (toasts.open.length === 1) toasts.open({ key, content: text, icon });
        else {
            // Mana toasts render icon as a component, while Revenge passes an asset ID
            const Icon = typeof icon === 'number'
                ? props => v.react.React.createElement(v.react.ReactNative.Image, {
                    ...props, source: icon, style: [{ width: 24, height: 24 }, props?.style],
                })
                : icon;
            toasts.open(key, { text, icon: Icon });
        }
    }
    const commands = [];
    let removeCommands;
    let unsubscribeCommands;
    let commandModule;
    let discoveringCommands = false;
    let commandsStopped = false;
    function builtinCommands(module) {
        try { return module.getBuiltInCommands(1, true, false); }
        catch { return module.getBuiltInCommands([1, 2, 3], true, false); }
    }
    function bindCommands(module) {
        if (commandsStopped || removeCommands || !commands.length) return;
        const builtins = builtinCommands(module);
        let id = Math.min(-1, ...builtins.map(item => Number(item.id)).filter(Number.isFinite));
        for (const command of commands) command.id = String(--id);
        commandModule = module;
        removeCommands = after('getBuiltInCommands', module, ([types], result) => [
            ...result,
            ...commands.filter(item => (Array.isArray(types) ? types : [types]).includes(item.type)),
        ]);
    }
    function discoverCommands() {
        if (discoveringCommands) {
            if (!removeCommands) {
                const module = findByProps('getBuiltInCommands');
                if (module) bindCommands(module);
            }
            return;
        }
        discoveringCommands = true;
        api.cleanup(() => {
            commandsStopped = true;
            unsubscribeCommands?.();
            removeCommands?.();
            commands.length = 0;
        });
        const module = findByProps('getBuiltInCommands');
        if (module) bindCommands(module);
        else unsubscribeCommands = v.modules.finders.getModules(
            filters.withProps('getBuiltInCommands'), bindCommands, { cached: false },
        );
    }
    function registerCommand(command) {
        const existing = commandModule ? builtinCommands(commandModule) : commands;
        const ids = existing.map(item => Number(item.id)).filter(Number.isFinite);
        Object.assign(command, {
            id: String(Math.min(-1, ...ids) - 1), applicationId: '-1', type: 1, inputType: 0,
            displayName: command.name, untranslatedName: command.name,
            displayDescription: command.description, untranslatedDescription: command.description,
        });
        for (const option of command.options ?? []) {
            option.displayName = option.name;
            option.displayDescription = option.description;
        }
        const execute = command.execute;
        command.execute = (...args) => {
            Promise.resolve().then(() => execute(...args)).catch(error => {
                console.error('Flarya command failed', error);
                showToast(String(error));
            });
        };
        commands.push(command);
        discoverCommands();
        return () => { const index = commands.indexOf(command); if (index >= 0) commands.splice(index, 1); };
    }
    return {
        logger: console,
        metro: {
            findByProps, findByName, findByStoreName, findByTypeNameAll, findAll,
            common: {
                React: v.react.React, ReactNative: v.react.ReactNative,
                constants: v.discord.common.constants.Constants,
                FluxDispatcher: v.discord.common.flux.Dispatcher,
                clipboard: v.externals.ReactNativeClipboard.Clipboard,
            },
        },
        patcher: { before, after },
        plugin: { storage: observable(state) },
        storage: { useProxy },
        utils: { findInReactTree },
        commands: { registerCommand },
        ui: { assets: { getAssetIDByName: v.assets.getAssetIdByName }, toasts: { showToast } },
        flush: () => writes,
    };
}

let legacy;
let compatibility;
return { default: plugin({
    jsonStorage: { default: {} },
    async start(api) {
        await api.jsonStorage.get();
        const vendetta = compatibility = createCompatibility(api);
        legacy = ((function (P, u, t, O, d, z, H) {
    "use strict";

    let w = [];
    let F;

    function x(v) {
        return v.startsWith("#") ? v : `#${v}`;
    }

    function $() {
        z.useProxy(d.storage);

        const View = t.ReactNative?.View;
        const Text = t.ReactNative?.Text;
        const TextInput = t.ReactNative?.TextInput;

        if (
            !View ||
            !Text ||
            !TextInput ||
            typeof t.React?.createElement !== "function"
        ) {
            return null;
        }

        const createColorSetting = function (label, key, defaultColor) {
            return t.React.createElement(
                View,
                {
                    key,
                    style: {
                        minHeight: 72,
                        flexDirection: "row",
                        alignItems: "center",
                        marginBottom: 8,
                    },
                },

                t.React.createElement(
                    View,
                    {
                        style: {
                            flex: 1,
                            paddingRight: 12,
                        },
                    },

                    t.React.createElement(
                        Text,
                        {
                            style: {
                                color: "white",
                                fontSize: 16,
                                fontWeight: "600",
                            },
                        },
                        label,
                    ),
                ),

                t.React.createElement(View, {
                    style: {
                        width: 24,
                        height: 24,
                        borderRadius: 4,
                        backgroundColor: x(
                            d.storage[key] ?? defaultColor,
                        ),
                        marginRight: 8,
                    },
                }),

                t.React.createElement(TextInput, {
                    style: {
                        color: "white",
                        fontSize: 14,
                        borderWidth: 1,
                        borderColor: "#444",
                        borderRadius: 6,
                        paddingHorizontal: 8,
                        paddingVertical: 4,
                        width: 100,
                    },

                    value: d.storage[key] ?? defaultColor,
                    placeholder: "hex color",
                    placeholderTextColor: "#666",

                    onChangeText: function (value) {
                        d.storage[key] = value
                            .replace(/[^0-9a-fA-F#]/g, "")
                            .slice(0, 7);
                    },
                }),
            );
        };

        return t.React.createElement(
            View,
            {
                style: {
                    paddingHorizontal: 16,
                    paddingVertical: 12,
                },
            },

            t.React.createElement(
                Text,
                {
                    style: {
                        color: "#B5BAC1",
                        fontSize: 22,
                        fontWeight: "700",
                        marginBottom: 8,
                    },
                },
                "PingColor Settings",
            ),

            createColorSetting(
                "Mention Background",
                "mentionColor",
                "f38ba8",
            ),

            createColorSetting(
                "Mention Bar",
                "mentionBarColor",
                "f38ba8",
            ),

            createColorSetting(
                "Reply Background",
                "replyColor",
                "cdd6f4",
            ),

            createColorSetting(
                "Reply Bar",
                "replyBarColor",
                "cdd6f4",
            ),
        );
    }

    function j(message, userId) {
        if (!message || !userId) {
            return false;
        }

        if (message.mentionEveryone) {
            return true;
        }

        const mentions = message.mentions;

        return Array.isArray(mentions)
            ? mentions.some(function (mention) {
                  const mentionId =
                      typeof mention === "string"
                          ? mention
                          : mention?.id;

                  return mentionId === userId;
              })
            : false;
    }

    function k(message, userId) {
        if (!message || !userId) {
            return false;
        }

        const referencedMessage =
            message.referencedMessage ??
            message.referenced_message;

        return referencedMessage?.author?.id === userId;
    }

    function D() {
        const userStore = u.findByProps(
            "getCurrentUser",
            "getUser",
        );

        const View = t.ReactNative?.View;

        if (
            !View ||
            typeof t.React?.createElement !== "function"
        ) {
            return;
        }

        for (const messageRow of u.findByTypeNameAll("MessageRow")) {
            if (typeof messageRow?.type !== "function") {
                continue;
            }

            w.push(
                O.after(
                    "type",
                    messageRow,

                    function (args, result) {
                        try {
                            const props = args?.[0];

                            const message =
                                props?.message ??
                                props?.item?.message ??
                                props?.content?.message;

                            if (!message) {
                                return;
                            }

                            const currentUserId =
                                userStore
                                    ?.getCurrentUser?.()
                                    ?.id;

                            const isMention = j(
                                message,
                                currentUserId,
                            );

                            const isReply = k(
                                message,
                                currentUserId,
                            );

                            if (!isMention && !isReply) {
                                return;
                            }

                            const mentionColor = x(
                                d.storage.mentionColor ??
                                    "f38ba8",
                            );

                            const mentionBarColor = x(
                                d.storage.mentionBarColor ??
                                    "f38ba8",
                            );

                            const replyColor = x(
                                d.storage.replyColor ??
                                    "cdd6f4",
                            );

                            const replyBarColor = x(
                                d.storage.replyBarColor ??
                                    "cdd6f4",
                            );

                            const backgroundColor =
                                isMention
                                    ? mentionColor
                                    : replyColor;

                            const borderColor =
                                isMention
                                    ? mentionBarColor
                                    : replyBarColor;

                            const processColor =
                                t.ReactNative?.processColor;

                            const processedBackground =
                                typeof processColor ===
                                "function"
                                    ? processColor(
                                          backgroundColor +
                                              "18",
                                      )
                                    : backgroundColor + "18";

                            const processedBorder =
                                typeof processColor ===
                                "function"
                                    ? processColor(borderColor)
                                    : borderColor;

                            const messageContainer =
                                H.findInReactTree(
                                    result,

                                    function (node) {
                                        return (
                                            node?.props?.style &&
                                            !node?.props
                                                ?.pingColorApplied &&
                                            (
                                                Array.isArray(
                                                    node.props
                                                        .children,
                                                ) ||
                                                node.props
                                                    .children
                                                    ?.props
                                            )
                                        );
                                    },
                                );

                            if (!messageContainer?.props) {
                                return;
                            }

                            messageContainer.props.pingColorApplied =
                                true;

                            const oldStyle =
                                messageContainer.props.style;

                            messageContainer.props.style = [
                                oldStyle,
                                {
                                    backgroundColor:
                                        processedBackground,
                                    borderLeftWidth: 3,
                                    borderLeftColor:
                                        processedBorder,
                                },
                            ];
                        } catch {
                            return;
                        }
                    },
                ),
            );
        }
    }

    const plugin = {
        onLoad: function () {
            d.storage.mentionColor ??= "f38ba8";
            d.storage.mentionBarColor ??= "f38ba8";
            d.storage.replyColor ??= "cdd6f4";
            d.storage.replyBarColor ??= "cdd6f4";

            F = setTimeout(function () {
                try {
                    D();
                } catch {}
            }, 1500);
        },

        onUnload: function () {
            if (F) {
                clearTimeout(F);
            }

            F = undefined;

            for (const unpatch of w.splice(0).reverse()) {
                try {
                    unpatch();
                } catch {}
            }
        },

        settings: $,
    };

    P.default = plugin;

    Object.defineProperty(P, "__esModule", {
        value: true,
    });

    return P;
})(
    {},
    vendetta.metro,
    vendetta.metro.common,
    vendetta.patcher,
    vendetta.plugin,
    vendetta.storage,
    vendetta.utils,
)).default;
        api.cleanup(async () => {
            try { legacy.onUnload?.(); }
            finally { legacy = undefined; await compatibility.flush(); }
        });
        legacy.onLoad?.();
    },
    SettingsComponent() {
        return legacy?.settings ? valenced.react.React.createElement(legacy.settings) : null;
    },
}) };
})()
